class Strings {
  static const String appName = "Time's Up";
}
