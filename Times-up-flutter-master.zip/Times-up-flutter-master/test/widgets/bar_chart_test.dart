import 'package:flutter_test/flutter_test.dart';

void main() {
  // THE complete tests should be implemented.
  test('Bar Chart Test', () => expect(1, 1));
}
