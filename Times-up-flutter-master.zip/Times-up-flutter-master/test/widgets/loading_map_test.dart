import 'package:flutter_test/flutter_test.dart';

void main() {
  // THE complete tests should be implemented.
  test('LoadingMap', () => expect(1, 1));
}
