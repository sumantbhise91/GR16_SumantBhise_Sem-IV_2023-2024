import 'package:flutter_test/flutter_test.dart';

void main() {
  // THE complete tests should be implemented.
  test('SharedPreference', () => expect(1, 1));
}
